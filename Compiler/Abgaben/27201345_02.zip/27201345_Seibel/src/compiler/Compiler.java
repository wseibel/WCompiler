package compiler;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

import org.junit.Assert;
import org.junit.Test;

public class Compiler {
	private static final char E = 'E';
	private static final char E_S = 'e';
	private static final char EXP = '7';
	private static final char DOT = '.';
	private static final char NUMBER = '9';
	private static final char START = 's';
	private static final char MANTISSA = '8';
	private int readPos;
	private int lookAheadPos;
	private Token currentToken = new Token();
	private String text;

	public double parse(String newText) {
		text = newText;
		// parse the text

		double result = 0;
		readPos = 0;
		lookAheadPos = 0;

		symbolTable = new LinkedHashMap<String, Double>();

		try {
			nextToken();
			nextToken();

			result = parseStatList();

			if (currentToken.kind != Character.MIN_VALUE) {
				parserError("end of text", text.length());
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

		return result;
	}

	private double parseStatList() {
		double result = 0;

		// statList ::= (assignment | expression)*

		while (currentToken.kind != Character.MIN_VALUE) {
			if (lookAheadToken.kind == '=') {
				result = parseAssignment();
			} else {
				result = parseExpression();
			}
		}

		return result;
	}

	private LinkedHashMap<String, Double> symbolTable;

	private double parseAssignment() {
		double result = 0;

		// assignment = varName = expression
		String varName = currentToken.text.toString();

		nextToken();
		skip('=');

		result = parseExpression();

		symbolTable.put(varName, result);

		return result;
	}

	private double parseExpression() {
		// expression ::= term [+|- term]*
		double result = 0;
		result = parseTerm();

		while ("+-".indexOf(currentToken.kind) >= 0) {

			// skip +|-
			char op = currentToken.kind;
			nextToken();

			double second = parseTerm();

			if (op == '+') {
				result += second;
			} else if (op == '-') {
				result -= second;
			}
		}
		return result;
	}

	private double parseTerm() {
		// term ::= factor [*|/ factor]*
		double result = 0;

		result = parseFactor();
		while (currentToken.kind == '*' || currentToken.kind == '/') {
			if (currentToken.kind == '*') {
				// skip *
				nextToken();

				result *= parseFactor();
			}
			if (currentToken.kind == '/') {
				// skip /
				nextToken();

				result /= parseFactor();
			}
		}
		return result;
	}

	private double parseFactor() {
		// factor ::= number | (expression) | varName
		double result = 0;

		if (currentToken.kind == '(') {
			// parse expression
			// skip (
			nextToken();

			result = parseExpression();

			// should be a )
			repair(')');
		} else if (Character.isLetter(currentToken.kind)) {

			// variable
			Double tableValue = symbolTable.get(currentToken.text.toString());

			if (tableValue == null) {
				parserError("variable " + currentToken.text + " has no value",
						text.indexOf(currentToken.text.toString()));
			} else {
				result = tableValue;
			}

			nextToken();
		} else {
			result = parseNumber();
		}

		return result;
	}

	private double parseNumber() {
		double result = 0;

		if (Character.isDigit(currentToken.kind)) {

			result = currentToken.value;

			nextToken();
		} else {
			parserError("Number expected", readPos - 1);
		}
		return result;
	}

	private void repair(char c) {
		if (currentToken.kind == c) {
			nextToken();
		} else {
			text = text + c;
			System.out.println(text + "\nMissing char " + c + " appended");
			nextToken();
		}
	}

	private void skip(char c) {
		if (currentToken.kind == c) {
			nextToken();
		} else {
			parserError(c + " is missing", readPos - 1);
		}
	}

	private void parserError(String Error, int errorPos) {
		StringBuffer blanks = new StringBuffer();
		for (int i = 0; i < errorPos && i < text.length(); i++) {
			blanks.append(' ');
		}
		throw new RuntimeException(Error + ": \n" + text + "\n"
				+ blanks.toString() + "^");
	}

	private Token lookAheadToken = new Token();

	private void nextToken() {
		Token tmp = currentToken;
		currentToken = lookAheadToken;
		lookAheadToken = tmp;
		lookAheadToken.text.setLength(0);

		readPos = lookAheadPos;

		int mantissaPos = 0;
		double exponent = 0;
		boolean expSign = true; // true means +, false -
		char currentChar = nextChar();
		lookAheadToken.kind = START;
		while (true) {
			switch (lookAheadToken.kind) {
			case START:
				if (Character.isWhitespace(currentChar)) {
					// skip
				} else if (Character.isDigit(currentChar)) {
					lookAheadToken.kind = NUMBER;
					lookAheadToken.value = currentChar - '0';
				} else if ("()*/+-=".indexOf(currentChar) >= 0) {
					// Operator detected
					lookAheadToken.kind = currentChar;
					return; // <======================= RETURN
				} else if (Character.isLetter(currentChar)) {
					lookAheadToken.kind = 'v';
				}
				break;

			case 'v':
				if (Character.isLetter(currentChar)
						|| Character.isDigit(currentChar)) {
					// go on
				} else {
					// varName has ended
					if (currentChar != Character.MIN_VALUE) {
						lookAheadPos--;
					}
					return;
				}
				break;
			case NUMBER:
				if (Character.isDigit(currentChar)) {
					lookAheadToken.value = lookAheadToken.value * 10
							+ currentChar - '0';
				} else if (currentChar == DOT) {
					lookAheadToken.kind = DOT;
				} else if (currentChar == E || currentChar == E_S) {
					lookAheadToken.kind = E;
				} else {
					// number has ended
					if (currentChar != Character.MIN_VALUE) {
						lookAheadPos--;
					}
					return; // <======================= RETURN
				}
				break;
			case DOT:
				if (Character.isDigit(currentChar)) {
					lookAheadToken.kind = MANTISSA;
					mantissaPos++;
					lookAheadToken.value = lookAheadToken.value
							+ ((currentChar - '0') / Math.pow(10, mantissaPos));
				} else {
					// number expected
					parserError("Digit expected", lookAheadPos - 1);
					return; // <======================= RETURN
				}
				break;
			case MANTISSA:
				if (Character.isDigit(currentChar)) {
					mantissaPos++;
					lookAheadToken.value = lookAheadToken.value
							+ ((currentChar - '0') / Math.pow(10, mantissaPos));
				} else if (currentChar == E || currentChar == E_S) {
					lookAheadToken.kind = E;
				} else {
					// number has ended
					if (currentChar != Character.MIN_VALUE
							&& currentChar != ' ') {
						lookAheadPos--;
						// digit expected
						parserError("Digit expected", lookAheadPos - 1);
					}
					return; // <======================= RETURN
				}
				break;
			case E:
				if (Character.isDigit(currentChar)) {
					exponent = exponent * 10 + currentChar - '0';
					lookAheadToken.kind = EXP;
				} else if ("+-".indexOf(currentChar) >= 0) {
					if (currentChar == '-') {
						// change exponents sign
						expSign = false;
					}
					lookAheadToken.kind = EXP;
				} else {
					lookAheadPos--;
					// digit expected
					parserError("Digit expected", lookAheadPos);
					return; // <======================= RETURN
				}
				break;
			case EXP:
				if (Character.isDigit(currentChar)) {
					exponent = exponent * 10 + currentChar - '0';
				} else {
					// exponent has ended
					if (currentChar != Character.MIN_VALUE
							&& currentChar != ' ') {
						lookAheadPos--;
						// digit expected
						parserError("Digit expected", lookAheadPos);
					}
					if (expSign) {
						lookAheadToken.value = lookAheadToken.value
								* Math.pow(10, exponent);
					} else {
						lookAheadToken.value = lookAheadToken.value
								* Math.pow(10, -exponent);
					}
					return; // <======================= RETURN
				}
				break;
			default:
				break;
			}
			if (currentChar == Character.MIN_VALUE) {
				lookAheadToken.kind = currentChar;
				return; // <======================= RETURN
			}
			if (!Character.isWhitespace(currentChar)) {
				lookAheadToken.text.append(currentChar);
			}
			currentChar = nextChar();
		}
	}

	public char nextChar() {
		char currentChar;
		if (lookAheadPos >= text.length()) {
			currentChar = Character.MIN_VALUE;
			lookAheadPos++;
		} else {
			currentChar = text.charAt(lookAheadPos);
			lookAheadPos++;
		}
		return currentChar;
	}
}
