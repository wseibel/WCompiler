package compiler;

import org.junit.Assert;
import org.junit.Test;

public class UnitTests {
	private String text;
	private Compiler compiler = new Compiler();

	@Test
	public void testConstants() {
		double result;
		String text = " ";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "0";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "9";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 9.0, result, 0.0000001);
	}

	@Test
	public void testPlus() {
		double result;
		text = "1++2";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1+";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1+2+3+4+5+6+7+8+9";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 45.0, result, 0.0000001);
	}

	@Test
	public void testMinus() {
		double result;
		text = "2--1";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1-";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1-4";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", -3.0, result, 0.0000001);

		text = "8-1-1-2-3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 1.0, result, 0.0000001);
	}

	@Test
	public void testMult() {
		double result;
		text = "2**3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "2*";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1*2*3*4*5";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 120.0, result, 0.0000001);
	}

	@Test
	public void testDiv() {
		double result;
		text = "6//2";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "2/";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "2/4";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.5, result, 0.0000001);

		text = "8/4";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 2.0, result, 0.0000001);
	}

	@Test
	public void testMixed() {
		double result;
		text = "4/2-1";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 1.0, result, 0.0000001);

		text = "1+2/4";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 1.5, result, 0.0000001);

		text = "2*3+3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 9.0, result, 0.0000001);

		text = "4+1*6";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 10.0, result, 0.0000001);

		text = "9-5-5+9-4";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 4.0, result, 0.0000001);

		text = "2*6/4";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 3.0, result, 0.0000001);

		text = "6/4*2";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 3.0, result, 0.0000001);
	}

	@Test
	public void testBrackets() {
		double result;

		text = "(((4)";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 4.0, result, 0.0000001);

		text = "1+(((((2*3)";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 7.0, result, 0.0000001);

		text = "(1+2)*3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 9.0, result, 0.0000001);

		text = "(1+2)/3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 1.0, result, 0.0000001);
	}

	@Test
	public void testMultiDigitNumbers() {
		double result;

		text = "42534";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 42534.0, result, 0.0000001);
	}

	@Test
	public void testAssignments() {
		double result;

		text = "i = 1 n = 2 i n 1 (1 + 3) 1 n ";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 2.0, result, 0.0000001);
		
		text = "x = 2 " + "y = x * x " + "y + 2 ";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 6.0, result, 0.0000001);
				
		text = "x = 2 " + "z = 1 " + "y = (3 * z) + x " + "y + 2 ";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 7.0, result, 0.0000001);

		text = "x = z ";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);
	}

	@Test
	public void testMultiCharVariables() {
		double result;
		
		text = "__var = 2 " + "num = __var * __var " + "num + 2 ";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 6.0, result, 0.0000001);
	}

	@Test
	public void testDecimalNumbers() {
		double result;

		text = "26.var";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "26.";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);
		
		text = "0.23 + 0.54";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.77, result, 0.0000001);
		
		text = "56.23567";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 56.23567, result, 0.0000001);
	}
	
	@Test
	public void testExponentialNumbers() {
		double result;

		text = "0.23e8var";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "0.23e";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "12E-3 * 12E-3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 0.000144, result, 0.0000001);

		text = "0.23e+3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 230, result, 0.0000001);

		text = "12E3";

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", 12000.0, result, 0.0000001);
	}
}
