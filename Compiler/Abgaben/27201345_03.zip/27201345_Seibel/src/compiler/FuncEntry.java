package compiler;

import java.util.ArrayList;

public class FuncEntry {
	public int funcStartPos = -1;
	
	public ArrayList<String> formParams = new ArrayList<String>();
}
