package compiler;

import org.junit.Assert;
import org.junit.Test;

public class UnitTests {
	private String text;
	private Compiler compiler = new Compiler();

	@Test
	public void testConstants() {

		String text = " ";
		test(text, 0.0);

		text = "";
		test(text, 0.0);

		text = "0";
		test(text, 0.0);

		text = "9";
		test(text, 9.0);
	}

	@Test
	public void testPlus() {

		text = "1++2";
		test(text, 0.0);

		text = "1+";
		test(text, 0.0);

		text = "1+2+3+4+5+6+7+8+9";
		test(text, 45.0);
	}

	@Test
	public void testMinus() {

		text = "2--1";
		test(text, 0.0);

		text = "1-";
		test(text, 0.0);

		text = "1-4";
		test(text, -3.0);

		text = "8-1-1-2-3";
		test(text, 1.0);
	}

	@Test
	public void testMult() {

		text = "2**3";
		test(text, 0.0);

		text = "2*";
		test(text, 0.0);

		text = "1*2*3*4*5";
		test(text, 120.0);
	}

	@Test
	public void testDiv() {

		text = "6//2";
		test(text, 0.0);

		text = "2/";
		test(text, 0.0);

		text = "2/4";
		test(text, 0.5);

		text = "8/4";
		test(text, 2.0);
	}

	@Test
	public void testMixed() {

		text = "4/2-1";
		test(text, 1.0);

		text = "1+2/4";
		test(text, 1.5);

		text = "2*3+3";
		test(text, 9.0);

		text = "4+1*6";
		test(text, 10.0);

		text = "9-5-5+9-4";
		test(text, 4.0);

		text = "2*6/4";
		test(text, 3.0);

		text = "6/4*2";
		test(text, 3.0);
	}

	@Test
	public void testBrackets() {

		text = "(((4)";
		test(text, 4);

		text = "1+(((((2*3)";
		test(text, 7.0);

		text = "(1+2)*3";
		test(text, 9.0);

		text = "(1+2)/3";
		test(text, 1.0);
	}

	@Test
	public void testMultiDigitNumbers() {

		text = "42534";
		test(text, 42534);
	}

	@Test
	public void testAssignments() {

		text = "i = 1 n = 2 i n 1 (1 + 3) 1 n ";
		test(text, 2.0);

		text = "x = 2 " + "y = x * x " + "y + 2 ";
		test(text, 6.0);

		text = "x = 20 " + "z = 10 " + "y = (3 * z) + x " + "y + 2 ";
		test(text, 52.0);

		text = "x = z ";
		test(text, 0.0);
	}

	@Test
	public void testMultiCharVariables() {
		text = "__var = 2 " + "num = __var * __var " + "num + 2 ";
		test(text, 6.0);
	}

	@Test
	public void testDecimalNumbers() {

		text = "26.var";
		test(text, 0.0);

		text = "26.";
		test(text, 0.0);

		text = "0.23 + 0.54";
		test(text, 0.77);

		text = "56.23567";
		test(text, 56.23567);
	}

	@Test
	public void testExponentialNumbers() {

		text = "0.23e8var";
		test(text, 0.0);

		text = "0.23e";
		test(text, 0.0);

		text = "12E-3 * 12E-3";
		test(text, 0.000144);

		text = "0.23e+3";
		test(text, 230);

		text = "12E3";
		test(text, 12000);
	}

	@Test
	public void testIf() {
		text = "value = 42 " + "if value > 0 " + "{ x = 42 }" + "else "
				+ "{ x = 23 }" + "x";

		test(text, 42);
	}

	@Test
	public void testWhile() {
		text = "i = 1 " + "sum = 0 " + "while i < 11 " + "{ "
				+ "	sum = sum + i " + "	i = i + 1 " + "} " + "sum";

		test(text, 55);
	}

	@Test
	public void testFunction() {

		text = "a = 1 "
				+ "function fact (x) { if x = 1 { x } else { x*fact ( x-1 ) } } "
				+ "fact(6)" + "";
		test(text, 720);

		text = "a = 1 " + "function sum (a b) { 2 * a + b } " + "sum (a 23) "
				+ "";
		test(text, 25);

		text = "function pi () { 3.1415927 } " + "r = 1 " + "l = 2 * pi() * r "
				+ "l";
		test(text, 2 * 3.1415927);
	}

	private void test(String text, double expected) {
		double result;

		result = compiler.parse(text);

		Assert.assertEquals("Wrong result: ", expected, result, 0.0000001);
	}
}
