package compiler;

import org.junit.Assert;
import org.junit.Test;

public class Compiler {
	private int readPos;
	private char currentChar;
	private String text;

	@Test
	public void testConstants() {
		double result;
		String text = " ";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "0";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "9";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 9.0, result, 0.0000001);
	}

	@Test
	public void testPlus() {
		double result;
		text = "1++2";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1+";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1+2+3+4+5+6+7+8+9";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 45.0, result, 0.0000001);
	}

	@Test
	public void testMinus() {
		double result;
		text = "2--1";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1-";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1-4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", -3.0, result, 0.0000001);

		text = "8-1-1-2-3";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 1.0, result, 0.0000001);
	}

	@Test
	public void testMult() {
		double result;
		text = "2**3";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "2*";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "1*2*3*4*5";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 120.0, result, 0.0000001);
	}

	@Test
	public void testDiv() {
		double result;
		text = "6//2";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "2/";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.0, result, 0.0000001);

		text = "2/4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 0.5, result, 0.0000001);

		text = "8/4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 2.0, result, 0.0000001);
	}

	@Test
	public void testMixed() {
		double result;
		text = "4/2-1";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 1.0, result, 0.0000001);

		text = "1+2/4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 1.5, result, 0.0000001);

		text = "2*3+3";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 9.0, result, 0.0000001);

		text = "4+1*6";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 10.0, result, 0.0000001);

		text = "9-5-5+9-4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 4.0, result, 0.0000001);

		text = "2*6/4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 3.0, result, 0.0000001);

		text = "6/4*2";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 3.0, result, 0.0000001);
	}

	@Test
	public void testBrackets() {
		double result;

		text = "(((4";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 4.0, result, 0.0000001);

		text = "1+(((((2*3)";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 7.0, result, 0.0000001);

		text = "(1+2)*3";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 9.0, result, 0.0000001);

		text = "(1+2)/3";

		result = parse(text);

		Assert.assertEquals("Wrong result: ", 1.0, result, 0.0000001);
	}

	public double parse(String newText) {
		text = newText;
		// parse the text

		double result = 0;
		readPos = 0;

		nextChar();

		try {
			result = parseExpression();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

		return result;
	}

	private double parseExpression() {
		// expression ::= term [+|- term]*
		double result = 0;
		result = parseTerm();

		while (currentChar == '+' || currentChar == '-') {
			if (currentChar == '+') {
				// skip +
				nextChar();

				result += parseTerm();
			}
			if (currentChar == '-') {
				// skip -
				nextChar();

				result -= parseTerm();
			}
		}
		return result;
	}

	private double parseTerm() {
		// term ::= number [*|/ number]*
		double result = 0;

		result = parseFactor();
		while (currentChar == '*' || currentChar == '/') {
			if (currentChar == '*') {
				// skip *
				nextChar();

				result *= parseNumber();
			}
			if (currentChar == '/') {
				// skip /
				nextChar();

				result /= parseNumber();
			}
		}
		return result;
	}

	private double parseFactor() {
		// factor ::= number | (expression)
		double result = 0;

		if (currentChar == '(') {
			// parse expression
			// skip (
			nextChar();

			result = parseExpression();

			// should be a )
			repair(')');
		} else {
			result = parseNumber();
		}

		return result;
	}

	private double parseNumber() {
		double result = 0;

		if (Character.isDigit(currentChar)) {

			result = currentChar - '0';

			nextChar();
		} else {
			parserError("Number expected");
		}
		return result;
	}

	private void repair(char c) {
		if (currentChar == c) {
			nextChar();
		} else {
			text = text + c;
			nextChar();		
		}
	}

	private void skip(char c) {
		if (c == ')') {
			nextChar();
		} else {
			parserError("Bracket");
		}
	}

	private void parserError(String Error) {
		StringBuffer blanks = new StringBuffer();
		for (int i = 0; i < readPos; i++) {
			blanks.append(' ');
		}
		throw new RuntimeException(Error + ": \n" + text + "\n"
				+ blanks.toString() + "^");
	}

	private void nextChar() {
		if (readPos >= text.length()) {
			currentChar = Character.MIN_VALUE;
		} else {
			currentChar = text.charAt(readPos);

			readPos++;
		}
	}
}
